package com.voltapulse.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** Akımın son 60 saniyesini gösteren yumuşak çizgi grafiği. */
public class ChartView extends View {
    private static final int MAX = 60;

    private final float[] buf = new float[MAX];
    private int n = 0;
    private int color = 0xFF3DF5C2;
    private final float d;

    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path linePath = new Path();

    public ChartView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;

        grid.setColor(0x14FFFFFF);
        grid.setStrokeWidth(1f * d);

        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2.5f * d);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);

        fill.setStyle(Paint.Style.FILL);

        dot.setStyle(Paint.Style.FILL);

        label.setColor(0xFF6F7BA8);
        label.setTextSize(10f * d);
        label.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    }

    public void push(float value, int color) {
        this.color = color;
        if (n < MAX) {
            buf[n++] = value;
        } else {
            System.arraycopy(buf, 1, buf, 0, MAX - 1);
            buf[MAX - 1] = value;
        }
        invalidate();
    }

    public void clear() {
        n = 0;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float left = 0f;
        float right = w - 6f * d;
        float top = 16f * d;
        float bottom = h - 4f * d;

        for (int i = 0; i < 4; i++) {
            float y = top + (bottom - top) * i / 3f;
            canvas.drawLine(left, y, w, y, grid);
        }

        if (n < 2) {
            label.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Veri toplanıyor…", w / 2f, h / 2f, label);
            return;
        }

        float min = buf[0];
        float max = buf[0];
        for (int i = 1; i < n; i++) {
            if (buf[i] < min) min = buf[i];
            if (buf[i] > max) max = buf[i];
        }
        float span = Math.max(max - min, 60f);
        float mid = (max + min) / 2f;
        float lo = mid - span * 0.6f;
        float hi = mid + span * 0.6f;
        if (lo < 0f) {
            hi -= lo;
            lo = 0f;
        }

        float step = (right - left) / (MAX - 1);
        float[] xs = new float[n];
        float[] ys = new float[n];
        for (int i = 0; i < n; i++) {
            xs[i] = right - (n - 1 - i) * step;
            ys[i] = bottom - (buf[i] - lo) / (hi - lo) * (bottom - top);
        }

        linePath.reset();
        linePath.moveTo(xs[0], ys[0]);
        for (int i = 1; i < n; i++) {
            float mx = (xs[i - 1] + xs[i]) / 2f;
            float my = (ys[i - 1] + ys[i]) / 2f;
            linePath.quadTo(xs[i - 1], ys[i - 1], mx, my);
        }
        linePath.lineTo(xs[n - 1], ys[n - 1]);

        Path area = new Path(linePath);
        area.lineTo(xs[n - 1], bottom);
        area.lineTo(xs[0], bottom);
        area.close();
        fill.setShader(new LinearGradient(0f, top, 0f, bottom,
                (color & 0x00FFFFFF) | 0x59000000, (color & 0x00FFFFFF),
                Shader.TileMode.CLAMP));
        canvas.drawPath(area, fill);

        line.setColor(color);
        canvas.drawPath(linePath, line);

        dot.setColor((color & 0x00FFFFFF) | 0x33000000);
        canvas.drawCircle(xs[n - 1], ys[n - 1], 8f * d, dot);
        dot.setColor(color);
        canvas.drawCircle(xs[n - 1], ys[n - 1], 4f * d, dot);

        label.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(Math.round(hi) + " mA", 2f * d, top - 4f * d, label);
        canvas.drawText(Math.round(lo) + " mA", 2f * d, bottom - 4f * d, label);
    }
}
