package com.voltapulse.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Yuvarlak uçlu ilerleme çubuğu. */
public class BarView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float frac = 0f;
    private int color = 0xFF3DF5C2;

    public BarView(Context c) {
        super(c);
        track.setColor(0x22FFFFFF);
    }

    public void set(float fraction, int color) {
        this.frac = Math.max(0f, Math.min(1f, fraction));
        this.color = color;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float r = h / 2f;
        rect.set(0f, 0f, w, h);
        canvas.drawRoundRect(rect, r, r, track);
        if (frac <= 0f) return;
        float fw = Math.max(h, w * frac);
        rect.set(0f, 0f, fw, h);
        fill.setShader(new LinearGradient(0f, 0f, fw, 0f,
                GaugeView.shade(color, 0.55f), color, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, r, r, fill);
    }
}
