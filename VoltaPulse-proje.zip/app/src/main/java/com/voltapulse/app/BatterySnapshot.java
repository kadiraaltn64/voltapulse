package com.voltapulse.app;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;

/** Bataryanın o anki durumunu okuyan basit veri sınıfı. */
final class BatterySnapshot {
    int level = 0;                                  // 0..100
    int status = BatteryManager.BATTERY_STATUS_UNKNOWN;
    int plugged = 0;
    int health = BatteryManager.BATTERY_HEALTH_UNKNOWN;
    int voltageMv = -1;
    float tempC = Float.NaN;
    String technology = "—";
    int cycleCount = -1;                            // Android 14+ bazı cihazlarda
    double currentMa = Double.NaN;                  // büyüklük (her zaman >= 0)
    double chargeCounterMah = Double.NaN;           // pilde kalan yük
    double estFullMah = Double.NaN;                 // tahmini tam dolu kapasite

    boolean isCharging() {
        return status == BatteryManager.BATTERY_STATUS_CHARGING;
    }

    static BatterySnapshot read(Context ctx) {
        BatterySnapshot s = new BatterySnapshot();

        Intent i = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i != null) {
            int lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (lvl >= 0 && scale > 0) s.level = Math.round(lvl * 100f / scale);
            s.status = i.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN);
            s.plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            s.health = i.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN);

            int v = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            if (v > 0 && v < 100) v = v * 1000;     // bazı cihazlar volt cinsinden verir
            s.voltageMv = v;

            int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            if (t != Integer.MIN_VALUE) s.tempC = t / 10f;

            String tech = i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
            if (tech != null && !tech.isEmpty()) s.technology = tech;

            s.cycleCount = i.getIntExtra("android.os.extra.CYCLE_COUNT", -1);
        }

        BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
        if (bm != null) {
            long raw = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
            if (raw != Long.MIN_VALUE && raw != Integer.MIN_VALUE) {
                double a = Math.abs((double) raw);
                // Çoğu cihaz mikroamper (µA) verir, bazıları miliamper (mA).
                s.currentMa = a >= 20000 ? a / 1000.0 : a;
            }

            long cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            if (cc > 0 && cc != Long.MIN_VALUE && cc != Integer.MIN_VALUE) {
                double mah = cc >= 100000 ? cc / 1000.0 : cc;
                s.chargeCounterMah = mah;
                if (s.level >= 15) {
                    double est = mah / (s.level / 100.0);
                    if (est >= 500 && est <= 20000) s.estFullMah = est;
                }
            }
        }
        return s;
    }
}
