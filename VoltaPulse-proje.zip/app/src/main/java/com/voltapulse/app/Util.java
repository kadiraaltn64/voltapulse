package com.voltapulse.app;

import android.os.BatteryManager;

import java.util.Locale;

final class Util {
    private Util() {}

    static String fmt(String f, Object... args) {
        return String.format(Locale.getDefault(), f, args);
    }

    /** Saat cinsinden süreyi "2 sa 05 dk" biçimine çevirir. */
    static String hm(double hours) {
        if (Double.isNaN(hours) || hours <= 0 || hours > 99) return "—";
        int totalMin = (int) Math.round(hours * 60);
        int h = totalMin / 60;
        int m = totalMin % 60;
        if (h > 0) return h + " sa " + (m < 10 ? "0" : "") + m + " dk";
        return m + " dk";
    }

    static String statusText(int st) {
        switch (st) {
            case BatteryManager.BATTERY_STATUS_CHARGING:
                return "Şarj oluyor";
            case BatteryManager.BATTERY_STATUS_DISCHARGING:
                return "Pil kullanımda";
            case BatteryManager.BATTERY_STATUS_FULL:
                return "Dolu";
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                return "Şarj olmuyor";
            default:
                return "Bilinmiyor";
        }
    }

    static String plugText(int plugged) {
        if ((plugged & BatteryManager.BATTERY_PLUGGED_AC) != 0) return "Duvar adaptörü";
        if ((plugged & BatteryManager.BATTERY_PLUGGED_USB) != 0) return "USB";
        if ((plugged & BatteryManager.BATTERY_PLUGGED_WIRELESS) != 0) return "Kablosuz şarj";
        return "Takılı değil";
    }

    static String healthText(int h) {
        switch (h) {
            case BatteryManager.BATTERY_HEALTH_GOOD:
                return "İyi";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                return "Aşırı sıcak";
            case BatteryManager.BATTERY_HEALTH_DEAD:
                return "Ölü";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                return "Aşırı voltaj";
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                return "Arıza";
            case BatteryManager.BATTERY_HEALTH_COLD:
                return "Aşırı soğuk";
            default:
                return "Bilinmiyor";
        }
    }
}
