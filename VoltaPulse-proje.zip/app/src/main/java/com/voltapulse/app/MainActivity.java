package com.voltapulse.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.SystemClock;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final int C_BG0 = 0xFF080D1C;
    private static final int C_BG1 = 0xFF111B3B;
    private static final int C_CARD = 0xFF141C38;
    private static final int C_TILE = 0xFF0E1530;
    private static final int C_STROKE = 0xFF222C54;
    private static final int C_TEXT = 0xFFF2F5FF;
    private static final int C_MUTED = 0xFF8F9BC8;
    private static final int C_GREEN = 0xFF3DF5C2;
    private static final int C_CYAN = 0xFF4CC9F0;
    private static final int C_AMBER = 0xFFFFB547;
    private static final int C_RED = 0xFFFF5C7A;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    private SharedPreferences prefs;
    private LinearLayout root;
    private int tick = 0;

    // Oturum istatistikleri
    private int sCount = 0;
    private double sSum = 0;
    private double sMin = Double.MAX_VALUE;
    private double sMax = 0;

    // Görünümler
    private GaugeView gauge;
    private TextView tvChip, tvCurrent, tvCurrentCaption, tvPower, tvEta;
    private ChartView chart;
    private TextView tvMin, tvAvg, tvMax;
    private TextView tvScore, tvVerdict, tvDead, tvReasons;
    private BarView healthBar;
    private TextView tvCapEst, tvCapDesign, tvCapPct, tvCycles;
    private TextView tvVolt, tvTemp, tvTech, tvOsHealth, tvPlug, tvCharge;
    private BarRow ramRow, storRow;
    private TextView tvUptime, tvPatch;
    private TextView tvTips;

    private static class BarRow {
        TextView value;
        BarView bar;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("volta", MODE_PRIVATE);
        getWindow().setStatusBarColor(C_BG0);
        getWindow().setNavigationBarColor(C_BG1);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    // ------------------------------------------------------------------ UI

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{C_BG0, C_BG1}));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(28));
        scroll.addView(root, new ViewGroup.LayoutParams(MATCH, WRAP));
        setContentView(scroll);

        // Başlık
        TextView title = text("VoltaPulse", 30, C_TEXT, true);
        root.addView(title, new LinearLayout.LayoutParams(MATCH, WRAP));
        TextView sub = text(Build.MANUFACTURER + " " + Build.MODEL + "  ·  Android " + Build.VERSION.RELEASE,
                13, C_MUTED, false);
        root.addView(sub, lpTop(2));

        buildHero();
        buildChartCard();
        buildHealthCard();
        buildCapacityCard();
        buildDetailsCard();
        buildSystemCard();
        buildTipsCard();

        TextView foot = text("Değerler Android'in verdiği bilgilere dayanır ve tahmindir. Üreticiye göre sapma olabilir.",
                11, C_MUTED, false);
        foot.setGravity(Gravity.CENTER);
        root.addView(foot, lpTop(18));
    }

    private void buildHero() {
        LinearLayout hero = card();
        hero.setGravity(Gravity.CENTER_HORIZONTAL);

        gauge = new GaugeView(this);
        hero.addView(gauge, new LinearLayout.LayoutParams(MATCH, dp(250)));

        tvChip = chip();
        hero.addView(tvChip, centered(lpTop(2)));

        tvCurrent = text("—", 46, C_TEXT, false);
        tvCurrent.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        tvCurrent.setGravity(Gravity.CENTER);
        hero.addView(tvCurrent, lpTop(14));

        tvCurrentCaption = text("", 13, C_MUTED, false);
        tvCurrentCaption.setGravity(Gravity.CENTER);
        hero.addView(tvCurrentCaption, lpTop(0));

        tvPower = text("", 15, C_TEXT, true);
        tvPower.setGravity(Gravity.CENTER);
        hero.addView(tvPower, lpTop(10));

        tvEta = text("", 13, C_MUTED, false);
        tvEta.setGravity(Gravity.CENTER);
        hero.addView(tvEta, lpTop(4));
    }

    private void buildChartCard() {
        LinearLayout card = card();
        titleRow(card, "Akım grafiği · son 60 sn", "Sıfırla", v -> {
            sCount = 0;
            sSum = 0;
            sMin = Double.MAX_VALUE;
            sMax = 0;
            chart.clear();
            tvMin.setText("—");
            tvAvg.setText("—");
            tvMax.setText("—");
        });

        chart = new ChartView(this);
        card.addView(chart, lpTopH(10, 150));

        LinearLayout row = hRow();
        tvMin = tile(row, "En düşük");
        tvAvg = tile(row, "Ortalama");
        tvMax = tile(row, "En yüksek");
        card.addView(row, lpTop(12));
    }

    private void buildHealthCard() {
        LinearLayout card = card();
        titleRow(card, "Batarya sağlığı", null, null);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.BOTTOM);
        tvScore = text("—", 52, C_GREEN, false);
        tvScore.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        top.addView(tvScore, new LinearLayout.LayoutParams(WRAP, WRAP));
        TextView of = text(" /100", 15, C_MUTED, false);
        LinearLayout.LayoutParams ofp = new LinearLayout.LayoutParams(WRAP, WRAP);
        ofp.bottomMargin = dp(8);
        top.addView(of, ofp);
        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
        tvVerdict = text("", 20, C_GREEN, true);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(WRAP, WRAP);
        vp.bottomMargin = dp(10);
        top.addView(tvVerdict, vp);
        card.addView(top, lpTop(6));

        healthBar = new BarView(this);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(MATCH, dp(10));
        bp.topMargin = dp(8);
        card.addView(healthBar, bp);

        LinearLayout deadRow = new LinearLayout(this);
        deadRow.setOrientation(LinearLayout.HORIZONTAL);
        deadRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView q = text("Batarya ölü mü?", 14, C_MUTED, false);
        deadRow.addView(q, new LinearLayout.LayoutParams(0, WRAP, 1f));
        tvDead = chip();
        deadRow.addView(tvDead, new LinearLayout.LayoutParams(WRAP, WRAP));
        card.addView(deadRow, lpTop(16));

        tvReasons = text("", 13, C_TEXT, false);
        tvReasons.setLineSpacing(dp(4), 1f);
        card.addView(tvReasons, lpTop(14));
    }

    private void buildCapacityCard() {
        LinearLayout card = card();
        titleRow(card, "Kapasite ve aşınma", null, null);

        LinearLayout r1 = hRow();
        tvCapEst = tile(r1, "Tahmini dolu kapasite");
        tvCapDesign = tile(r1, "Tasarım kapasitesi");
        card.addView(r1, lpTop(12));

        LinearLayout r2 = hRow();
        tvCapPct = tile(r2, "Kapasite sağlığı");
        tvCycles = tile(r2, "Şarj döngüsü");
        card.addView(r2, lpTop(10));

        TextView btn = action("Tasarım kapasitesini gir", C_CYAN, v -> askDesignCapacity());
        card.addView(btn, lpTop(14));
    }

    private void buildDetailsCard() {
        LinearLayout card = card();
        titleRow(card, "Ayrıntılar", null, null);

        LinearLayout r1 = hRow();
        tvVolt = tile(r1, "Voltaj");
        tvTemp = tile(r1, "Sıcaklık");
        card.addView(r1, lpTop(12));

        LinearLayout r2 = hRow();
        tvTech = tile(r2, "Teknoloji");
        tvOsHealth = tile(r2, "Sistem durumu");
        card.addView(r2, lpTop(10));

        LinearLayout r3 = hRow();
        tvPlug = tile(r3, "Şarj kaynağı");
        tvCharge = tile(r3, "Pilde kalan yük");
        card.addView(r3, lpTop(10));
    }

    private void buildSystemCard() {
        LinearLayout card = card();
        titleRow(card, "Telefon durumu", null, null);

        ramRow = barRow(card, "RAM kullanımı");
        storRow = barRow(card, "Depolama");

        LinearLayout r = hRow();
        tvUptime = tile(r, "Açık kalma süresi");
        tvPatch = tile(r, "Güvenlik yaması");
        card.addView(r, lpTop(16));
    }

    private void buildTipsCard() {
        LinearLayout card = card();
        titleRow(card, "Telefon sağlığı için ipuçları", null, null);
        tvTips = text("", 13, C_TEXT, false);
        tvTips.setLineSpacing(dp(5), 1f);
        card.addView(tvTips, lpTop(12));
    }

    // -------------------------------------------------------------- refresh

    private void refresh() {
        BatterySnapshot s = BatterySnapshot.read(this);
        tick++;
        int color = levelColor(s);
        updateHero(s, color);
        updateChart(s, color);
        updateHealth(s);
        updateDetails(s);
        if (tick % 5 == 1) {
            updateSystem();
            tvTips.setText(join(HealthAnalyzer.tips(s)));
        }
    }

    private int levelColor(BatterySnapshot s) {
        if (s.isCharging()) return C_GREEN;
        if (s.level <= 15) return C_RED;
        if (s.level <= 30) return C_AMBER;
        return C_CYAN;
    }

    private void updateHero(BatterySnapshot s, int color) {
        boolean charging = s.isCharging();
        gauge.set(s.level, Util.statusText(s.status), color, charging);

        String chipText = s.plugged != 0 ? Util.plugText(s.plugged) + " bağlı" : "Şarja takılı değil";
        setChip(tvChip, chipText, color);

        if (Double.isNaN(s.currentMa)) {
            tvCurrent.setText("—");
            tvCurrent.setTextColor(C_TEXT);
            tvCurrentCaption.setText("Bu telefon anlık akım değerini paylaşmıyor");
        } else {
            String num = String.valueOf(Math.round(s.currentMa));
            SpannableString ss = new SpannableString(num + " mA");
            ss.setSpan(new RelativeSizeSpan(0.38f), num.length(), ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            tvCurrent.setText(ss);
            tvCurrent.setTextColor(color);
            if (charging) {
                tvCurrentCaption.setText("Şarj akımı · pile giren");
            } else if (s.status == BatteryManager.BATTERY_STATUS_DISCHARGING) {
                tvCurrentCaption.setText("Deşarj akımı · pilden çıkan");
            } else {
                tvCurrentCaption.setText("Anlık akım");
            }
        }

        double volts = s.voltageMv > 0 ? s.voltageMv / 1000.0 : Double.NaN;
        if (!Double.isNaN(s.currentMa) && !Double.isNaN(volts)) {
            double watts = s.currentMa / 1000.0 * volts;
            tvPower.setText(Util.fmt("%.2f W   ·   %.2f V", watts, volts));
        } else if (!Double.isNaN(volts)) {
            tvPower.setText(Util.fmt("%.2f V", volts));
        } else {
            tvPower.setText("");
        }

        String eta = "";
        if (!Double.isNaN(s.currentMa) && s.currentMa > 30 && !Double.isNaN(s.chargeCounterMah)) {
            if (charging && !Double.isNaN(s.estFullMah)) {
                double hours = (s.estFullMah - s.chargeCounterMah) / s.currentMa;
                String t = Util.hm(hours);
                if (!t.equals("—")) eta = "Dolmasına yaklaşık " + t;
            } else if (!charging && s.status == BatteryManager.BATTERY_STATUS_DISCHARGING) {
                String t = Util.hm(s.chargeCounterMah / s.currentMa);
                if (!t.equals("—")) eta = "Bu akımla yaklaşık " + t + " dayanır";
            }
        }
        tvEta.setText(eta);
    }

    private void updateChart(BatterySnapshot s, int color) {
        if (Double.isNaN(s.currentMa)) return;
        chart.push((float) s.currentMa, color);
        sCount++;
        sSum += s.currentMa;
        sMin = Math.min(sMin, s.currentMa);
        sMax = Math.max(sMax, s.currentMa);
        tvMin.setText(ma(sMin));
        tvAvg.setText(ma(sSum / sCount));
        tvMax.setText(ma(sMax));
    }

    private void updateHealth(BatterySnapshot s) {
        HealthAnalyzer.Result r = HealthAnalyzer.analyze(s, prefs.getInt("design_mah", 0));
        int col = r.dead ? C_RED : (r.score >= 70 ? C_GREEN : (r.score >= 50 ? C_AMBER : C_RED));
        tvScore.setText(String.valueOf(r.score));
        tvScore.setTextColor(col);
        tvVerdict.setText(r.verdict);
        tvVerdict.setTextColor(col);
        healthBar.set(r.score / 100f, col);

        int dcol = r.deadLevel == 0 ? C_GREEN : (r.deadLevel == 1 ? C_AMBER : C_RED);
        setChip(tvDead, r.deadAnswer, dcol);
        tvReasons.setText(join(r.reasons));

        int design = prefs.getInt("design_mah", 0);
        tvCapEst.setText(Double.isNaN(s.estFullMah) ? "—" : Math.round(s.estFullMah) + " mAh");
        tvCapDesign.setText(design > 0 ? design + " mAh" : "Girilmedi");
        if (Double.isNaN(r.capacityPct)) {
            tvCapPct.setText("—");
            tvCapPct.setTextColor(C_TEXT);
        } else {
            tvCapPct.setText("%" + Math.round(r.capacityPct));
            tvCapPct.setTextColor(r.capacityPct >= 85 ? C_GREEN : (r.capacityPct >= 70 ? C_AMBER : C_RED));
        }
        tvCycles.setText(s.cycleCount > 0 ? String.valueOf(s.cycleCount) : "Verilmiyor");
    }

    private void updateDetails(BatterySnapshot s) {
        tvVolt.setText(s.voltageMv > 0 ? Util.fmt("%.2f V", s.voltageMv / 1000.0) : "—");
        if (Float.isNaN(s.tempC)) {
            tvTemp.setText("—");
            tvTemp.setTextColor(C_TEXT);
        } else {
            tvTemp.setText(Util.fmt("%.1f °C", s.tempC));
            tvTemp.setTextColor(s.tempC >= 45f ? C_RED : (s.tempC >= 40f ? C_AMBER : C_TEXT));
        }
        tvTech.setText(s.technology);
        tvOsHealth.setText(Util.healthText(s.health));
        tvOsHealth.setTextColor(s.health == BatteryManager.BATTERY_HEALTH_GOOD ? C_GREEN
                : (s.health == BatteryManager.BATTERY_HEALTH_UNKNOWN ? C_TEXT : C_RED));
        tvPlug.setText(s.plugged != 0 ? Util.plugText(s.plugged) : "Yok");
        tvCharge.setText(Double.isNaN(s.chargeCounterMah) ? "—" : Math.round(s.chargeCounterMah) + " mAh");
    }

    private void updateSystem() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        if (am != null) am.getMemoryInfo(mi);
        long total = mi.totalMem;
        long used = total - mi.availMem;
        float rf = total > 0 ? used / (float) total : 0f;
        ramRow.value.setText(gb(used) + " / " + gb(total));
        ramRow.bar.set(rf, usageColor(rf));

        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            long st = sf.getTotalBytes();
            long su = st - sf.getAvailableBytes();
            float f = st > 0 ? su / (float) st : 0f;
            storRow.value.setText(gb(su) + " / " + gb(st));
            storRow.bar.set(f, usageColor(f));
        } catch (Exception e) {
            storRow.value.setText("—");
        }

        long up = SystemClock.elapsedRealtime() / 1000;
        long days = up / 86400;
        long hours = (up % 86400) / 3600;
        long mins = (up % 3600) / 60;
        tvUptime.setText(days > 0 ? days + " g " + hours + " sa" : hours + " sa " + mins + " dk");
        tvPatch.setText(Build.VERSION.SECURITY_PATCH != null ? Build.VERSION.SECURITY_PATCH : "—");
    }

    // ------------------------------------------------------------- diyalog

    private void askDesignCapacity() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("örn. 5000");
        int cur = prefs.getInt("design_mah", 0);
        if (cur > 0) et.setText(String.valueOf(cur));
        new AlertDialog.Builder(this)
                .setTitle("Tasarım kapasitesi (mAh)")
                .setMessage("Telefonunun kutusundaki ya da teknik özelliklerindeki nominal pil kapasitesi.")
                .setView(et)
                .setPositiveButton("Kaydet", (d, w) -> {
                    String txt = et.getText().toString().trim();
                    int val = 0;
                    try {
                        val = Integer.parseInt(txt);
                    } catch (NumberFormatException ignored) {
                    }
                    if (val >= 500 && val <= 20000) {
                        prefs.edit().putInt("design_mah", val).apply();
                    } else if (txt.isEmpty()) {
                        prefs.edit().remove("design_mah").apply();
                    }
                })
                .setNegativeButton("İptal", null)
                .show();
    }

    // ------------------------------------------------------------ yardımcılar

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static String ma(double v) {
        return Math.round(v) + " mA";
    }

    private static String gb(long bytes) {
        return Util.fmt("%.1f GB", bytes / 1073741824.0);
    }

    private static int usageColor(float f) {
        return f < 0.70f ? C_GREEN : (f < 0.88f ? C_AMBER : C_RED);
    }

    private static String join(List<String> lines) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) sb.append('\n');
            sb.append(lines.get(i));
        }
        return sb.toString();
    }

    private GradientDrawable rounded(int color, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean medium) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        return t;
    }

    private LinearLayout.LayoutParams lpTop(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(topDp);
        return lp;
    }

    private LinearLayout.LayoutParams lpTopH(int topDp, int heightDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, dp(heightDp));
        lp.topMargin = dp(topDp);
        return lp;
    }

    private LinearLayout.LayoutParams centered(LinearLayout.LayoutParams lp) {
        LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(WRAP, WRAP);
        c.topMargin = lp.topMargin;
        c.gravity = Gravity.CENTER_HORIZONTAL;
        return c;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(16), dp(18), dp(18));
        l.setBackground(rounded(C_CARD, 24, C_STROKE));
        root.addView(l, lpTop(14));
        return l;
    }

    private LinearLayout hRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private void titleRow(LinearLayout card, String title, String actionLabel, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(title, 16, C_TEXT, true);
        row.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
        if (actionLabel != null) row.addView(action(actionLabel, C_CYAN, click));
        card.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
    }

    private TextView action(String label, int color, View.OnClickListener click) {
        TextView t = text(label, 13, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(9), dp(14), dp(9));
        t.setBackground(rounded((color & 0x00FFFFFF) | 0x26000000, 20, 0));
        t.setOnClickListener(click);
        return t;
    }

    private TextView chip() {
        TextView t = text("", 12, C_TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(6), dp(14), dp(6));
        return t;
    }

    private void setChip(TextView tv, String s, int color) {
        tv.setText(s);
        tv.setTextColor(color);
        tv.setBackground(rounded((color & 0x00FFFFFF) | 0x26000000, 20, 0));
    }

    private TextView tile(LinearLayout row, String label) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        t.setBackground(rounded(C_TILE, 16, 0));
        TextView l = text(label, 11, C_MUTED, false);
        TextView v = text("—", 17, C_TEXT, true);
        t.addView(l, new LinearLayout.LayoutParams(WRAP, WRAP));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(WRAP, WRAP);
        vp.topMargin = dp(4);
        t.addView(v, vp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        if (row.getChildCount() > 0) lp.leftMargin = dp(10);
        row.addView(t, lp);
        return v;
    }

    private BarRow barRow(LinearLayout card, String label) {
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView l = text(label, 13, C_MUTED, false);
        TextView v = text("—", 13, C_TEXT, true);
        v.setGravity(Gravity.END);
        top.addView(l, new LinearLayout.LayoutParams(0, WRAP, 1f));
        top.addView(v, new LinearLayout.LayoutParams(WRAP, WRAP));
        card.addView(top, lpTop(14));

        BarView b = new BarView(this);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(MATCH, dp(8));
        bp.topMargin = dp(8);
        card.addView(b, bp);

        BarRow r = new BarRow();
        r.value = v;
        r.bar = b;
        return r;
    }
}
