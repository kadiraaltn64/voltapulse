package com.voltapulse.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** Pil seviyesini gösteren dairesel gösterge. */
public class GaugeView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pct = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cap = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bolt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final Path boltPath = new Path();

    private float level = 0f;
    private float target = -1f;
    private String caption = "";
    private int color = 0xFF3DF5C2;
    private boolean charging = false;
    private ValueAnimator anim;

    public GaugeView(Context c) {
        super(c);
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setColor(0x1FFFFFFF);

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);

        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);

        num.setTextAlign(Paint.Align.LEFT);
        num.setColor(0xFFF2F5FF);
        num.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));

        pct.setTextAlign(Paint.Align.LEFT);
        pct.setColor(0xFF8F9BC8);
        pct.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));

        cap.setTextAlign(Paint.Align.CENTER);
        cap.setColor(0xFF8F9BC8);
        cap.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));

        bolt.setStyle(Paint.Style.FILL);
    }

    public void set(float lv, String caption, int color, boolean charging) {
        this.caption = caption;
        this.color = color;
        this.charging = charging;
        float clamped = Math.max(0f, Math.min(100f, lv));
        if (Math.abs(clamped - target) > 0.01f) {
            target = clamped;
            if (anim != null) anim.cancel();
            anim = ValueAnimator.ofFloat(level, target);
            anim.setDuration(700);
            anim.setInterpolator(new DecelerateInterpolator());
            anim.addUpdateListener(a -> {
                level = (Float) a.getAnimatedValue();
                invalidate();
            });
            anim.start();
        } else {
            invalidate();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    public static int shade(int c, float f) {
        return Color.argb(Color.alpha(c),
                Math.min(255, (int) (Color.red(c) * f)),
                Math.min(255, (int) (Color.green(c) * f)),
                Math.min(255, (int) (Color.blue(c) * f)));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float size = Math.min(w, h);
        float cx = w / 2f;
        float cy = h / 2f;
        float stroke = size * 0.075f;
        float r = size / 2f - stroke * 1.4f;
        oval.set(cx - r, cy - r, cx + r, cy + r);

        track.setStrokeWidth(stroke);
        canvas.drawArc(oval, 135f, 270f, false, track);

        float sweep = 270f * Math.max(0f, Math.min(100f, level)) / 100f;
        if (sweep > 0.5f) {
            glow.setStrokeWidth(stroke * 2.1f);
            glow.setColor((color & 0x00FFFFFF) | 0x26000000);
            canvas.drawArc(oval, 135f, sweep, false, glow);

            arc.setStrokeWidth(stroke);
            float end = Math.max(0.02f, sweep / 360f);
            SweepGradient sg = new SweepGradient(cx, cy,
                    new int[]{shade(color, 0.5f), color},
                    new float[]{0f, end});
            Matrix m = new Matrix();
            m.setRotate(135f, cx, cy);
            sg.setLocalMatrix(m);
            arc.setShader(sg);
            canvas.drawArc(oval, 135f, sweep, false, arc);
        }

        // Yüzde yazısı
        num.setTextSize(size * 0.22f);
        pct.setTextSize(size * 0.085f);
        String s = String.valueOf(Math.round(level));
        float numW = num.measureText(s);
        float pctW = pct.measureText("%");
        float gap = size * 0.012f;
        float startX = cx - (numW + gap + pctW) / 2f;
        Paint.FontMetrics fm = num.getFontMetrics();
        float baseline = cy - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(s, startX, baseline, num);
        canvas.drawText("%", startX + numW + gap, baseline - size * 0.075f, pct);

        // Alt başlık
        cap.setTextSize(size * 0.058f);
        canvas.drawText(caption, cx, baseline + size * 0.14f, cap);

        // Şarj yıldırımı
        if (charging) {
            float bw = size * 0.055f;
            float bh = size * 0.09f;
            float bx = cx - bw / 2f;
            float by = baseline - size * 0.21f - bh;
            boltPath.reset();
            boltPath.moveTo(bx + 0.62f * bw, by);
            boltPath.lineTo(bx + 0.12f * bw, by + 0.58f * bh);
            boltPath.lineTo(bx + 0.48f * bw, by + 0.58f * bh);
            boltPath.lineTo(bx + 0.36f * bw, by + bh);
            boltPath.lineTo(bx + 0.90f * bw, by + 0.38f * bh);
            boltPath.lineTo(bx + 0.54f * bw, by + 0.38f * bh);
            boltPath.close();
            bolt.setColor(color);
            canvas.drawPath(boltPath, bolt);
        }
    }
}
