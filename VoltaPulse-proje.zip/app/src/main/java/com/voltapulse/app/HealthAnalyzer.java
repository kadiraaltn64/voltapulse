package com.voltapulse.app;

import android.os.BatteryManager;

import java.util.ArrayList;
import java.util.List;

/** Batarya sağlığını puanlar, "ölü mü?" sorusunu yanıtlar ve ipuçları üretir. */
final class HealthAnalyzer {
    private HealthAnalyzer() {}

    static final class Result {
        int score = 100;                 // 0..100
        String verdict = "";
        boolean dead = false;
        int deadLevel = 0;               // 0 = hayır, 1 = şüpheli, 2 = evet
        String deadAnswer = "";
        double capacityPct = Double.NaN;
        final List<String> reasons = new ArrayList<>();
    }

    static Result analyze(BatterySnapshot s, int designMah) {
        Result r = new Result();
        int score = 100;
        int suspicious = 0;

        switch (s.health) {
            case BatteryManager.BATTERY_HEALTH_DEAD:
                r.dead = true;
                r.reasons.add("▲ Sistem bataryayı ÖLÜ olarak raporluyor.");
                break;
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                score -= 55;
                suspicious++;
                r.reasons.add("▲ Sistem belirsiz bir batarya arızası bildiriyor.");
                break;
            case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                score -= 35;
                r.reasons.add("▲ Batarya aşırı ısınmış. Şarjı kes ve telefonu soğut.");
                break;
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                score -= 40;
                suspicious++;
                r.reasons.add("▲ Aşırı voltaj algılandı. Adaptörü/kabloyu değiştir.");
                break;
            case BatteryManager.BATTERY_HEALTH_COLD:
                score -= 15;
                r.reasons.add("▲ Batarya çok soğuk; performans geçici olarak düşebilir.");
                break;
            case BatteryManager.BATTERY_HEALTH_GOOD:
                r.reasons.add("✓ Sistem batarya durumunu 'iyi' bildiriyor.");
                break;
            default:
                r.reasons.add("• Sistem sağlık durumunu bildirmiyor.");
                break;
        }

        if (!r.dead) {
            // Sıcaklık
            if (!Float.isNaN(s.tempC)) {
                if (s.tempC >= 45f) {
                    score -= 25;
                    r.reasons.add(Util.fmt("▲ Sıcaklık çok yüksek (%.1f °C).", s.tempC));
                } else if (s.tempC >= 40f) {
                    score -= 12;
                    r.reasons.add(Util.fmt("▲ Sıcaklık yüksek (%.1f °C).", s.tempC));
                } else if (s.tempC <= 0f) {
                    score -= 15;
                    r.reasons.add(Util.fmt("▲ Sıcaklık çok düşük (%.1f °C).", s.tempC));
                } else {
                    r.reasons.add(Util.fmt("✓ Sıcaklık normal (%.1f °C).", s.tempC));
                }
            }

            // Voltaj
            if (s.voltageMv > 0) {
                if (s.voltageMv < 3300 && s.level > 10) {
                    score -= 30;
                    suspicious++;
                    r.reasons.add(Util.fmt("▲ Voltaj (%.2f V) şarj seviyesine göre çok düşük; hücre zayıflamış olabilir.", s.voltageMv / 1000.0));
                } else if (s.voltageMv > 4500) {
                    score -= 25;
                    suspicious++;
                    r.reasons.add(Util.fmt("▲ Voltaj (%.2f V) olması gerekenden yüksek.", s.voltageMv / 1000.0));
                } else {
                    r.reasons.add(Util.fmt("✓ Voltaj normal aralıkta (%.2f V).", s.voltageMv / 1000.0));
                }
            }

            // Kapasite
            if (!Double.isNaN(s.estFullMah)) {
                if (designMah > 0) {
                    double pct = s.estFullMah / designMah * 100.0;
                    if (pct > 130) {
                        r.reasons.add("• Girdiğin tasarım kapasitesi tahminle uyuşmuyor; değeri kontrol et.");
                    } else {
                        r.capacityPct = Math.min(100.0, pct);
                        if (pct < 60) { score -= 40; suspicious++; }
                        else if (pct < 70) score -= 30;
                        else if (pct < 80) score -= 18;
                        else if (pct < 90) score -= 8;
                        if (pct >= 90) {
                            r.reasons.add(Util.fmt("✓ Kapasite çok iyi (~%%%d).", Math.round(Math.min(100.0, pct))));
                        } else {
                            r.reasons.add(Util.fmt("▲ Kapasite azalmış (~%%%d). Yeni gibi değil.", Math.round(pct)));
                        }
                    }
                } else {
                    r.reasons.add("• Aşınmayı görmek için tasarım kapasitesini gir (aşağıdaki kart).");
                }
            } else if (s.level < 15) {
                r.reasons.add("• Kapasite tahmini için pil %15'in üzerinde olmalı.");
            }

            // Şarj döngüsü
            if (s.cycleCount > 0) {
                if (s.cycleCount > 1000) score -= 25;
                else if (s.cycleCount > 800) score -= 15;
                else if (s.cycleCount > 500) score -= 8;
                r.reasons.add((s.cycleCount > 500 ? "▲ " : "✓ ") + "Şarj döngüsü: " + s.cycleCount);
            }

            // Şarj anomali
            if (s.status == BatteryManager.BATTERY_STATUS_CHARGING && s.level < 95
                    && !Double.isNaN(s.currentMa) && s.currentMa < 20) {
                score -= 10;
                r.reasons.add("▲ Şarj görünüyor ama akım neredeyse yok: kablo/adaptör arızalı olabilir ya da batarya şarjı kabul etmiyor.");
            }
        }

        if (r.dead) score = 0;
        score = Math.max(0, Math.min(100, score));
        r.score = score;

        if (r.dead) {
            r.deadLevel = 2;
            r.deadAnswer = "Evet, ölü";
            r.verdict = "Ölü";
            r.reasons.add("▲ Bataryanın değiştirilmesi gerekir.");
        } else {
            if (suspicious >= 1 && score < 55) {
                r.deadLevel = 1;
                r.deadAnswer = "Şüpheli";
            } else {
                r.deadLevel = 0;
                r.deadAnswer = "Hayır, ölü değil";
            }
            if (score >= 85) r.verdict = "Mükemmel";
            else if (score >= 70) r.verdict = "İyi";
            else if (score >= 50) r.verdict = "Orta";
            else if (score >= 30) r.verdict = "Zayıf";
            else r.verdict = "Kritik";
        }
        return r;
    }

    static List<String> tips(BatterySnapshot s) {
        List<String> t = new ArrayList<>();
        boolean charging = s.status == BatteryManager.BATTERY_STATUS_CHARGING;

        if (!Float.isNaN(s.tempC) && s.tempC >= 40f) {
            t.add(Util.fmt("• Telefon sıcak (%.1f °C). Kılıfı çıkar, ağır uygulamaları kapat, soğumasını bekle.", s.tempC));
        }
        if (charging && s.level >= 80) {
            t.add("• Pil %" + s.level + " oldu. Uzun ömür için şarjı %80–90 civarında kesmek hücreyi daha az yorar.");
        }
        if (!charging && s.level <= 20) {
            t.add("• Şarj %20'nin altında. Pili sık sık sıfıra yakın tüketmek ömrünü kısaltır.");
        }
        if (charging && !Double.isNaN(s.currentMa) && s.currentMa >= 3000) {
            t.add(Util.fmt("• Çok hızlı şarj oluyor (%d mA). Isınma olursa daha düşük güçlü adaptör kullan.", Math.round(s.currentMa)));
        }
        if (!charging && !Double.isNaN(s.currentMa) && s.currentMa >= 800) {
            t.add(Util.fmt("• Pil şu an yüksek akım çekiyor (%d mA). Parlak ekran, GPS veya oyun olabilir.", Math.round(s.currentMa)));
        }

        String[] fixed = {
                "• Orijinal ya da sertifikalı kablo/adaptör kullan; ucuz şarj aletleri bataryayı bozar.",
                "• Gece boyu şarjda bırakma; mümkünse %20–80 aralığında tut.",
                "• Telefonu sıcak ortamda (araç içi, güneş altı) şarj etme.",
                "• Ekran parlaklığını otomatiğe al, kullanmadığın uygulamaları arka planda kısıtla.",
                "• Pili ayda bir tam boşaltmak gerekmez; bu bilgi eski pil türleri için geçerliydi."
        };
        for (String f : fixed) {
            if (t.size() >= 5) break;
            t.add(f);
        }
        return t;
    }
}
