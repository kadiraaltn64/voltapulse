# VoltaPulse – Kurulum

Pil akımını (mA), gücü (W), voltajı, sıcaklığı canlı gösteren; bataryanın
sağlığını puanlayan ve "ölü mü?" sorusunu yanıtlayan Android uygulaması.

## APK'yı GitHub ile derleme (bilgisayar gerekmez)

1. github.com'da ücretsiz hesap aç, yeni bir depo (repository) oluştur.
2. **Add file → Upload files** ile bu zip dosyasını (açmadan) depoya yükle, "Commit" de.
3. **Add file → Create new file** de, dosya adına `.github/workflows/build.yml`
   yaz, zip'in içindeki `.github/workflows/build.yml` içeriğini yapıştır, "Commit" de.
4. **Actions** sekmesinde "APK derle" çalışır (yaklaşık 3-5 dk). Yeşil tik olunca
   depo ana sayfasında sağdaki **Releases → VoltaPulse APK** bölümünden
   `VoltaPulse.apk` dosyasını telefonundan indir.
5. APK'ya dokun → "Bilinmeyen kaynaklardan yüklemeye izin ver" → Kur.

## Android Studio ile

Klasörü Android Studio'da aç → Build → Build APK(s).
Gereksinim: JDK 17, Android SDK 34.
